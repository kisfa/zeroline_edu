# -*- coding: utf-8 -*-

from dataclasses import dataclass
from heapq import heappop, heappush
from math import atan2, degrees, hypot

from qgis.core import QgsCoordinateTransform, QgsPointXY, QgsProject, QgsRaster


SLOPE_TOLERANCE_PERCENT = 0.5


@dataclass(frozen=True)
class SearchParameters:
    target_slope_percent: float
    arrival_radius_m: float
    search_angle_degrees: float
    max_expansions: int
    turn_penalty: float
    max_detour_factor: float


@dataclass
class SearchResult:
    points: list
    length: float
    arrival_distance_m: float
    mean_slope_percent: float
    min_slope_percent: float
    max_slope_percent: float
    expanded_nodes: int


class NeutralLineError(Exception):
    pass


class RasterSampler:
    def __init__(self, raster_layer, source_crs):
        self.layer = raster_layer
        self.provider = raster_layer.dataProvider()
        self.extent = raster_layer.extent()
        self.width = raster_layer.width()
        self.height = raster_layer.height()
        self.x_size = self.extent.width() / self.width
        self.y_size = self.extent.height() / self.height
        self.step_size = (abs(self.x_size) + abs(self.y_size)) / 2
        self.to_raster = QgsCoordinateTransform(
            source_crs, raster_layer.crs(), QgsProject.instance()
        )
        self.from_raster = QgsCoordinateTransform(
            raster_layer.crs(), source_crs, QgsProject.instance()
        )
        self._z_cache = {}

    def to_cell(self, point):
        raster_point = self.to_raster.transform(QgsPointXY(point))
        if not self.extent.contains(raster_point):
            raise NeutralLineError("A megadott pont a DEM kiterjedesen kivul van.")

        col = int((raster_point.x() - self.extent.xMinimum()) / self.x_size)
        row = int((self.extent.yMaximum() - raster_point.y()) / self.y_size)
        return self._clamp_cell(row, col)

    def cell_center(self, cell):
        row, col = cell
        x = self.extent.xMinimum() + (col + 0.5) * self.x_size
        y = self.extent.yMaximum() - (row + 0.5) * self.y_size
        return QgsPointXY(x, y)

    def map_point(self, cell):
        return self.from_raster.transform(self.cell_center(cell))

    def elevation(self, cell):
        if cell in self._z_cache:
            return self._z_cache[cell]

        if not self.in_bounds(cell):
            return None

        result = self.provider.identify(
            self.cell_center(cell), QgsRaster.IdentifyFormatValue
        )
        if not result.isValid():
            self._z_cache[cell] = None
            return None

        values = result.results()
        value = values.get(1)
        if value is None:
            self._z_cache[cell] = None
            return None

        try:
            value = float(value)
        except (TypeError, ValueError):
            self._z_cache[cell] = None
            return None

        self._z_cache[cell] = value
        return value

    def in_bounds(self, cell):
        row, col = cell
        return 0 <= row < self.height and 0 <= col < self.width

    def distance(self, a, b):
        ar, ac = a
        br, bc = b
        return hypot((bc - ac) * self.x_size, (br - ar) * self.y_size)

    def direct_distance(self, a, b):
        return self.distance(a, b)

    def _clamp_cell(self, row, col):
        row = min(max(row, 0), self.height - 1)
        col = min(max(col, 0), self.width - 1)
        return row, col


class NeutralLineFinder:
    DIRECTIONS = (
        (-1, 0),
        (-1, 1),
        (0, 1),
        (1, 1),
        (1, 0),
        (1, -1),
        (0, -1),
        (-1, -1),
    )

    def __init__(self, raster_layer, map_crs):
        self.sampler = RasterSampler(raster_layer, map_crs)

    def find(self, start_point, end_point, params):
        start = self.sampler.to_cell(start_point)
        goal = self.sampler.to_cell(end_point)

        if self.sampler.elevation(start) is None:
            raise NeutralLineError("A kezdopont alatt nincs ervenyes DEM ertek.")
        if self.sampler.elevation(goal) is None:
            raise NeutralLineError("A celpont alatt nincs ervenyes DEM ertek.")
        if start == goal:
            raise NeutralLineError("A ket pont ugyanabba a DEM cellaba esik.")

        direct_distance = self.sampler.direct_distance(start, goal)
        if direct_distance <= params.arrival_radius_m:
            raise NeutralLineError("A kezdopont mar a celpont erkezesi korzeteben van.")

        max_path_length = direct_distance * max(params.max_detour_factor, 1.0)
        best_state = self._search(start, goal, params, max_path_length)
        if best_state is None:
            raise NeutralLineError(
                "Nem talaltam vonalat a megadott erkezesi sugar, keresszog es lepeskorlat mellett."
            )

        path_cells, expanded = best_state
        points = [self.sampler.map_point(cell) for cell in path_cells]
        slopes = self._path_slopes(path_cells)
        length = self._path_length(path_cells)
        arrival_distance = self.sampler.direct_distance(path_cells[-1], goal)
        return SearchResult(
            points=points,
            length=length,
            arrival_distance_m=arrival_distance,
            mean_slope_percent=sum(slopes) / len(slopes) if slopes else 0.0,
            min_slope_percent=min(slopes) if slopes else 0.0,
            max_slope_percent=max(slopes) if slopes else 0.0,
            expanded_nodes=expanded,
        )

    def _search(self, start, goal, params, max_path_length):
        start_state = (start[0], start[1], -1)
        frontier = []
        heappush(frontier, (0.0, start_state))
        came_from = {start_state: None}
        cell_for_state = {start_state: start}
        cost_so_far = {start_state: 0.0}
        length_so_far = {start_state: 0.0}
        expanded = 0

        while frontier:
            _, current_state = heappop(frontier)
            current = cell_for_state[current_state]
            expanded += 1

            if expanded > params.max_expansions:
                break
            if self._is_goal(current, goal, params):
                return self._reconstruct(came_from, cell_for_state, current_state), expanded

            for direction_index, neighbor in self._neighbors(current):
                if not self._inside_search_cone(current, neighbor, goal, params):
                    continue

                step_length = self.sampler.distance(current, neighbor)
                new_length = length_so_far[current_state] + step_length
                if new_length > max_path_length:
                    continue

                step_slope = self._step_slope(current, neighbor, step_length)
                if step_slope is None:
                    continue

                slope_error = abs(step_slope - params.target_slope_percent)
                if slope_error > SLOPE_TOLERANCE_PERCENT:
                    continue

                turn_cost = self._turn_cost(current_state[2], direction_index, params)
                slope_cost = self._slope_cost(slope_error)
                step_cost = step_length * (1.0 + turn_cost + slope_cost)
                new_cost = cost_so_far[current_state] + step_cost
                next_state = (neighbor[0], neighbor[1], direction_index)

                if next_state not in cost_so_far or new_cost < cost_so_far[next_state]:
                    cost_so_far[next_state] = new_cost
                    length_so_far[next_state] = new_length
                    priority = new_cost + self.sampler.direct_distance(neighbor, goal)
                    heappush(frontier, (priority, next_state))
                    came_from[next_state] = current_state
                    cell_for_state[next_state] = neighbor

        return None

    def _neighbors(self, cell):
        row, col = cell
        for index, (row_delta, col_delta) in enumerate(self.DIRECTIONS):
            neighbor = (row + row_delta, col + col_delta)
            if self.sampler.in_bounds(neighbor):
                yield index, neighbor

    def _step_slope(self, current, neighbor, step_length):
        current_z = self.sampler.elevation(current)
        neighbor_z = self.sampler.elevation(neighbor)
        if current_z is None or neighbor_z is None or step_length == 0:
            return None
        return ((neighbor_z - current_z) / step_length) * 100.0

    def _path_slopes(self, path_cells):
        slopes = []
        for current, neighbor in zip(path_cells, path_cells[1:]):
            length = self.sampler.distance(current, neighbor)
            slope = self._step_slope(current, neighbor, length)
            if slope is not None:
                slopes.append(slope)
        return slopes

    def _path_length(self, path_cells):
        return sum(
            self.sampler.distance(current, neighbor)
            for current, neighbor in zip(path_cells, path_cells[1:])
        )

    def _is_goal(self, current, goal, params):
        return self.sampler.direct_distance(current, goal) <= params.arrival_radius_m

    @staticmethod
    def _slope_cost(slope_error):
        return slope_error / SLOPE_TOLERANCE_PERCENT

    def _inside_search_cone(self, current, neighbor, goal, params):
        if params.search_angle_degrees >= 360:
            return True

        to_goal_row = goal[0] - current[0]
        to_goal_col = goal[1] - current[1]
        to_neighbor_row = neighbor[0] - current[0]
        to_neighbor_col = neighbor[1] - current[1]
        angle = abs(
            self._angle_difference(
                degrees(atan2(to_goal_row, to_goal_col)),
                degrees(atan2(to_neighbor_row, to_neighbor_col)),
            )
        )
        return angle <= params.search_angle_degrees / 2.0

    @staticmethod
    def _angle_difference(a, b):
        return (a - b + 180.0) % 360.0 - 180.0

    @staticmethod
    def _turn_cost(previous_direction, direction, params):
        if previous_direction < 0:
            return 0.0

        turn_steps = abs(previous_direction - direction)
        turn_steps = min(turn_steps, len(NeutralLineFinder.DIRECTIONS) - turn_steps)
        return params.turn_penalty * (turn_steps / 4.0)

    @staticmethod
    def _reconstruct(came_from, cell_for_state, state):
        path = []
        while state is not None:
            path.append(cell_for_state[state])
            state = came_from[state]
        path.reverse()
        return path
